/**
 * 
Please check CasperJs documentation what can be use to define steps http://docs.casperjs.org/en/latest/modules/ 

Helper methods that can be used (but not inside evaluation context):
 */
// logs message
helper.log("log message");

//exit script execution
helper.exit();
//exit script execution with error
helper.exitWithError(msg, errorCode, trace);
//downloads pdf file and exits
helper.downloadFileAndExit(this);
//captures last opened page to specified pdf file and exits
helper.renderPageAndExit(file);
//extract pdf file and exist. DEPRACATED - always download file in casperjs to be consistent
helper.extractPdfUrlAndExit(pdfUrl);


