var casper = require('casper').create({
    verbose: false,
    logLevel: "info",
    pageSettings: {
        webSecurityEnabled: false
    },
    onWaitTimeout: function(){
    	helper.exitTimeout("Wait Timeout");
    },
    onStepTimeout: function(){
    	helper.exitTimeout("Step Timeout");
    },
    onTimeout : function(){
    	helper.exitTimeout("Timeout");
    }
});

var require = patchRequire(require);
var response = {error : {}, logStack : [] };

var helper = {
		exit : function(){
			//write down response
			casper.echo(JSON.stringify(response));
	        casper.exit();
		},
		exitWithError : function(msg, errorCode, trace){
			response.error = {};
			response.error.message = msg;
			if (errorCode) response.error.code = errorCode;
			if (trace) response.error.trace = trace;
			helper.exit();
		},
		exitValidationFailed: function(message){
			helper.log("Exiting as validation failed - " + message);
			response.error = {};
			response.error.status = "CONTENT_VALIDATION_ERROR";
			helper.exit();
		},
		exitUnknownSource: function(message){
			helper.log("Exiting as unknown source - " + message);
			response.error = {};
			response.error.status = "UNKNOWN_SOURCE";
			response.error.message = message;
			helper.exit();
		},
		exitTimeout: function(message){
			helper.log("Exiting as timeout occured - " + message);
			response.error = {};
			response.error.status = "EXECUTION_TIMEOUT";
			response.error.message = message;
			helper.exit();
		},
		log: function (logMsg){
			response.logStack.push(logMsg);
		},
		downloadFileAndExit : function(file){
			helper.log("Will download file " + file);
			casper.download(file, output);
			response.outputFile = output;
			helper.exit();
		},
		extractPdfUrlAndExit : function(pdfUrl){
			helper.log("Extracted pdf url " + pdfUrl);
			response.extractedUrl = pdfUrl;
			helper.exit();
		},
		renderPageAndExit : function(page){
			casper.page.paperSize = {
					  format:'A4',
					  orientation: 'portrait',
					  margin: '1cm'
					};
			page.capture(output);
            response.outputFile = output;
			helper.exit();
		},
		caspervalidation : function(){
			casper.on('http.status.404', function(resource) {
				helper.exitValidationFailed("404 status code!" + resource.url);
			});
			casper.on('http.status.500', function(resource) {
				helper.exitValidationFailed("woops, 500 error");
			});
			casper.on('http.status.400', function(resource) {
				helper.exitValidationFailed("400 status code!");
			});
		}
	};


//MAIN ENTRY
if (casper.cli.args.length < 3 || casper.cli.args.length > 5) {
    helper.exitWithError("Wrong arguments - Usage: script.js URL filename snippet.js");
} else {
	helper.log("starting casperjs script ");
	var address = casper.cli.args[0];
	var snippetScript = casper.cli.args[2];
	var snippet = {};
	if (snippetScript){
		snippet = require(snippetScript);
	} 
	//include basic validation
	helper.caspervalidation();
	
	
    output = casper.cli.args[1];
    
    casper.run(function() {
        helper.exit();
    });
    
}





