casper.start(address, function() {
    var validate = this.evaluate(function() {
        var elems = document.getElementsByTagName('h1'), i;
        for (i in elems) {
            if(( elems[i].innerHTML) !== undefined && ( elems[i].innerHTML).indexOf('Not Found') > -1) {
                return false;
            }
        }
        return true;
    });
    if (validate){
        helper.renderPageAndExit(this);
    } else {
        helper.exitValidationFailed("Validation failed - perhaps pdf is not found anymore");
    }
});