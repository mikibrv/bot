casper.start(address, function() {
	helper.renderPageAndExit(this);
});