//casperjs will not download pdf unless its start with opening some correct url.. it will also not work with opening address.
casper.start("http://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js", function() {
	helper.downloadFileAndExit(address);
});
