casper.start(address, function() {
	var validate = this.evaluate(function() {
		return $("div#articledetail").length>0;
	});
	if (validate){
		helper.renderPageAndExit(this);
	} else {
		helper.exitValidationFailed("Didn't find div#articledetail");
	}
});